tests needed:



G610	diode board (for core)
G611	diode board (for core)
G624	resistors and caps
G700	terminator
G718	jumper board
G780	power connector
G805	negative regulator
G817	power supply card for 713 (VR12)
G818	power supply card for 713 (VR12)
G824	+5V regulator for PDP12
G826	regulator control (drives G805, power ok circuits)
G836	VR14 Power Supply and Regulator
G838	VR14 Fault Protection Board
G847	Dual Motor Voltage Control (drives G848) (TU56)
G848	Motor Control (TU56)
G850	SCR Motor Driver (TU55)
G851	Tape Relay Board (TU55, TU56)
G853	DEC Tape misc, Single Unit Selection and Timing
G859	Clock and Regulator (TU56)
G882	Manchester Reader Writer (TC12)
G888	Manchester Reader Writer (TU56/TD8E)
G912	Deflection Amplifier, -12 AMPS into 30 uH Push-Pull Yoke, 15us full defection (VR12)
G916	Power Detector and Switch Filter (PDP12)
G917	XY Control (gain and offset) (VR12)
G918	Photo Transistor Amplifier (PT04)

M101	Bus Data Interface (7400, clamps to ground)
M103	Device Selector
M141	AND/NOR GATES open colector (3 7401s, 1 7420)
M221    barely started (similar to M220, but moved pins)
M222    good start, needs more tests
M302	Dual One Shot Delay
M304	Quad one-shots, 100ns or 1usec only
M307	Dual Integrating One-Shot, 5us to 500 ms.
M401	Variable Clock
M405	Crystal Clock
M452	Variable Clock (/2, /4 outputs)
M503	Dual differential Schmitt Trigger + Power Amplifer
M507	6 Bus Converters (negibus to TTL open collector) (Gnd in -> Gnd out)
M508	6 Bus Converters (negibus to TTL open collector) (Gnd in -> o.c.)
M516	6 Positive Bus Receivers
M531	8 Negative Bus Converter with noise filtering
M602	Dual Pulse Generator
M623	12 Bus Drivers (TTL to open collector) (100 ma)
M627	6 4-input NANDs (3 74H40) (H version of M617)
M651	3 Negative Output Converter
M660	3 Positive Level Driver for 8/I bus
M700	Manual Timing Generator- filters, one-shots
M703	Power Fail for 8/I
M704	Plotter Control
M705	Reader Control
M706D   need rev D (teletype receiver)
M706K   needs work
M710	Punch Control
M711	Scope Control
M715	Reader Clock
M719	KW12 Clock Input Synchronizer
M720	Memory Detection
M760	A-D Control
M850	EIA FUll Duplex Level Convertor (W076 pins)
M870	Simple Clock (PDP12)

last line.

